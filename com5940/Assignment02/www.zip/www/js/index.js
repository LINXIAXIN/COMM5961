document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    console.log('It is working...')
}